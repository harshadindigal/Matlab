function [ntrialWins, ntrialVec]= montyHall(ntrials,decideSwitch,plotsOn)
%inputs: ntrials (number of trials), decideSwitch (whether or not to
%switch), plotsOn (graph decision)

%initializations 
counter = 1;
pointofrepitition = ntrials/50;
totalsum = 0;
winningarraycounter = 1;

%runs ntrial number of games
while counter <= ntrials
%door chosen by contestant
doorchosen = randi(3);
%whether or not to switch after 1st door is revealed
if(decideSwitch() >= .5)
   doorchoice = 1;
else
   doorchoice = 0;
end

%keeps track if current trial if win or not
runningsum = chooseDoor(doorchosen, doorchoice);
%total number of wins
totalsum = totalsum + runningsum;
%outputs:

%if current trial is a multiple of ntrials/50
if rem(counter, pointofrepitition) == 0
   %percentage of wins
   ntrialWins(winningarraycounter) = totalsum/counter;
   %number of trials passed
   ntrialVec(winningarraycounter) = counter;
   
   winningarraycounter = winningarraycounter + 1;
end
%next trial
counter = counter + 1;
end
%plot
h = strcmp(plotsOn, 'on');
if h == 1
    plot(ntrialVec, ntrialWins,'-*');
    grid on
    xlabel('Number of Trials');
    ylabel('Probability of Winning');
    title(sprintf('Monty Hall Problem for Decision Function %d',func2str(decideSwitch)));
end
end
function [ win ] = chooseDoor( door, switch_door )
%correct door
correctdoor = randi(3);
%if contestant chooses the correct door and doesn't switch
if door == correctdoor && switch_door == 0
    win = 1;
end
%if contestant chooses the correct door and switches
if door == correctdoor && switch_door == 1
    win = 0;
end
%if contestant choses the wrong door and doesn't switch
if door ~= correctdoor && switch_door == 0
    win = 0;
end
%if contestant choses the wrong does and switches
if door ~= correctdoor && switch_door == 1
    win = 1;
end
end

