function [ A_n1, B_n1, A_n1_error, B_n1_error  ] = polygonArea(delta )
%inputs: delta

n = 3; %minimum number of sides for a complete shape
A_n = (n/2)*sin((2*pi)/n); %A_n area formula    
B_n = n*tan(pi/n);  %B_n area formula

%Initializations
A_n1 = 0; 
B_n1 = 0;
A_n1_error = 0;
B_n1_error = 0;

%Outputs:

while abs(A_n1 - A_n) >= delta || abs(B_n1 - B_n) >= delta && n < (10^6) %continues while 
    n = n+1; %iterates n by 1                                            %loop if either differences 
    A_n = (n/2)*sin(2*pi/n);                                             %between succesive area's is 
    B_n = n*tan(pi/n);                                                   %less than the tolerance or inteations < 10^6
    %area for n+1'th term
    A_n1 =((n+1)/2)*sin(2*pi/(n+1)); 
    B_n1 = (n+1)*tan(pi/(n+1));
    %error for n+1'th term
    A_n1_error = abs(pi - A_n1);
    B_n1_error = abs(pi - B_n1);
    
end
    

end

