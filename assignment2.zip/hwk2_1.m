n = 100; %initialization
disp('n     R_error      T_error    U_error'); % display of chart titles
disp('-------------------------------------');
while n <= 1000
    R = 0;
    T = 0;
    U = 0;
for n = 1:n
    R = R + ((-1)^(n+1))/((2*n)-1);
    T = T + (1/(n^2));
    U = U + (1/(n^4));
end

R= 4*R;  T= sqrt(6*T); U = (90*U)^((1/4));
fprintf('%d %10.2d %12.2d %9.2d\n',n,round(pi-R,5),round(pi-T,5),round(pi-U,12)); %displays the interation count, R_error, T_error, and U_error
n = n + 100; %iteration counter
end