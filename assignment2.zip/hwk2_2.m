disp('n              a_n                   a_error'); % display of chart titles
disp('---------------------------------------------'); 
a_n=0;
b_n=0;
c = 0;
d = 0;
term1 = 0;
term2 = 0;
while abs(((a_n)*(6 / sqrt(3)))-pi) >= (10^(-15)) && c<=20;
a_n = a_n + ((-1)^(c))/((3^c)*((2*c)+1));
fprintf('%d %25.12d %15.2d\n',c, ((a_n)*(6 / sqrt(3))),abs(((a_n)*(6 / sqrt(3)))-pi)); %displays the count, a_n, and error value while less than specified tolerance or count <= 20
c = c+1;
end
disp('n              b_n                   b_error');
disp('----------------------------------------------');
while abs(((term1*16)-(4*term2)) -pi) >= (10^(-15)) && d<=20;
term1 = term1 + ((-1)^(d))/((5^((2*d)+1))*((2*d)+1));
term2 = term2 + ((-1)^(d))/((239^((2*d)+1))*((2*d)+1));
fprintf('%d %25.12d %15.2d\n',d, (term1 * 16) - (4*(term2)),abs((term1 * 16) - (4*(term2))-pi)); %displays the count, b_n, and error value while less than specified tolerance or count <= 20
d = d +1;
end
