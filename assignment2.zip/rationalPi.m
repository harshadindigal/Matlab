function [ pBest, qBest, err_pq ] = rationalPi( d )
%inputs: d

% Initializations...
pBest = 1;                      % Best numerator ``found so far''
qBest = 1;                      % Best denominator ``found so far''...
err_pq = abs(pBest/qBest - pi); % Error in current best fraction...
count = 1;                      % current interation of the while loop

%outputs: 

% Check out all possible numerators...
while err_pq >= 10^(-d) % keeps track if 'best' error is > tolerance
   count = count + 1;     
    p = count;  %p variable inialized (constantly increasing)
   
    % Initializations for the q-search...
    q0 = 1;
    e0 = abs(pi - p/q0);
    % For this q, find the best numerator p0...
 for q =1:p
      if abs(pi - p/q) < e0
            % A new best numerator has been found for this q...
            q0 = q;
            e0 = abs(pi - p/q);
      end
 end
    % Check to see if we have a new best quotient for this q...
    if  e0 < err_pq
        pBest = p;
        qBest = q0;
        err_pq = e0;
    end

end

end

