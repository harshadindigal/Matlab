
%%
disp('test1')
tol=1e-6;
f=@(x) 3*x^4 -5*x^3 - 12*x^2;
fDeriv=@(x) 12*x^3-15*x^2-24*x;
x0=-1;
root_correct = [-1.333333];
[root]=newtonRoot(f,fDeriv,x0,tol);
tol1=1e-4;
assert( abs(root-root_correct) < tol1 , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n'   ], ...
      root,root_correct);
%%
disp('test2')
tol=1e-6;
f=@(x) 3*x^4 -5*x^3 - 12*x^2;
fDeriv=@(x) 12*x^3-15*x^2-24*x;
x0=2.5;
root_correct = [3.000];
[root]=newtonRoot(f,fDeriv,x0,tol);
tol1=1e-4;
assert( abs(root-root_correct) < tol1 , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n'   ], ...
      root,root_correct);
  %%
disp('test3')
tol=1e-6;
f=@(x) 3*x^4 -5*x^3 - 12*x^2;
fDeriv=@(x) 12*x^3-15*x^2-24*x;
x0=1;
root_correct = [2.632740591412851e-04];
[root]=newtonRoot(f,fDeriv,x0,tol);
tol1=1e-4;
assert( abs(root-root_correct) < tol1 , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n'   ], ...
      root,root_correct);
  %%
disp('test4')
tol=1e-6;
f=@(x) 3*x^4 -5*x^3 - 12*x^2;
fDeriv=@(x) 12*x^3-15*x^2-24*x;
x0=-0.5;
root_correct = [-7.8477e-05];
[root]=newtonRoot(f,fDeriv,x0,tol);
tol1=1e-4;
assert( abs(root-root_correct) < tol1 , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n'   ], ...
      root,root_correct);