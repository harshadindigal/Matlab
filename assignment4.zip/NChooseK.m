function [combination] = NChooseK( n,k )
%inputs: n , k

%outputs: number of combinations once can select k objects from a set of n
%objects:

%if total choices(n) are greater than k objects
if n >= k
combination = myFactorial(n)/(myFactorial(k) * myFactorial(n-k));

else
%Combination is undefined/Not possible 
    combination = NaN;
    return
end


end

