function [ root ] = MyCubeRoot( A, tol )
%inputs: A (any integer that is inputed to be square-rooted
%        tol(a certain value that the cube-root "error" must be under)

%counters
n = 1;
p = 1;

%output: cube root A^(1/3)
if A == 0
    % Nothing to do in this case...
    root = 0;
else
    %if A is negative, output must be negative
    if A<0
 
     % The initial rectangular prism is A-by-1-by-1...
     L = abs(A); W = 1; H = 1;
    
     % Iterate until the difference between L and W is less than L*tol or <
     % 1000 iterations
        while abs(L-W) >  tol*L && n <= 1000
         % The new L is the average of the current L and W and H...
        L = (L+W+ H)/3; H = L; W = abs(A)/(L*H); 
        n = n+1;
        end
        root = -L;
    
    %if A is positive, output must be positive
    else
     L = A; W = 1; H = 1;
    % Iterate until the difference between L and W is less than L*tol or <
    % 1000 iterations
        while abs(L-W) >  tol*L && p <= 1000
        % The new L is the average of the current L and W...
        L = (L+W+ H)/3; H = L; W = A/(L*H); 
        p = p + 1;
        end
        root = L;
    end
end

