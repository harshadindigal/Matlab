
function [root] = findRoot( x0, tol )
%inputs: x0 and tolerance

%calls localfunction newtonRoot to calculate root
root = newtonRoot(@f,@fDeriv,x0,tol);
%plot of x-values (50) from -2 to 3.25
xplot = linspace(-2,3.25);
%corresponing vector of f(x) values
y = f(xplot);

figure
%plots x and f(x) values 
plot(xplot,y);
hold on
grid on

%highlights the zero of the function
plot(root, f(root),'ro')
%highlights the initial x of the function
plot(x0, f(x0),'bo')

%graph labels
legend('f(x)','f(x) = 0', 'f(x0)')
xlabel('x')
ylabel('f(x)')
title(sprintf('Roots of f(x) = 3*x^4 -5*x^3 - 12*x^2 Using Newtons Method for tol = %d',tol))


end
%function
function y = f(x)
y = 3*x.^4 -5*x.^3 - 12*x.^2;
end
%function derivitive 
function z = fDeriv(x)
z = ((12)*(x.^3)) - ((15)*(x.^2)) - (24*x) ;
end