%initializations 
n = 1;
a = 1;

% Largest positive floating-point number
b = realmax;

%output: corresponding n which factorial is the smallest that is not a
%machine precise number

%chekcs to see if the n+1! is still less than b
while a < b
  %n+1! factorial
   a = myFactorial(n+1);
   %current n
   n = n + 1;
end
%display
display(sprintf('%d is the smallest n such that myFactorial(n)\nis not a machine precision number',n));