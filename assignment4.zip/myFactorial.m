function [ fact ] = myFactorial( n )
%input: n

%intialization 
fact = 1;

%output: n!

%if n is 0, factorial is 1
if(n == 0)
fact = 1;
return
end
%if n > 1, multiply n by n-1,n-2...n-i so long that n-i >= 1
while n>=1
fact = fact * n;
n = n -1;
end

end

