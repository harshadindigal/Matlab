
%%
disp('test1')
A=7;
tol=1e-9;
root_correct = 1.912931182772774;
root = MyCubeRoot(A,tol);
assert( max(abs(root-root_correct))< tol  , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n' ], ...
      root,root_correct);
%%
disp('test2')
A=27;
tol=1e-6;
root_correct = 3;
root = MyCubeRoot(A,tol);
assert( max(abs(root-root_correct))< tol  , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n' ], ...
      root,root_correct);
%%
disp('test3')
A=-27;
tol=1e-6;
root_correct = -3;
root = MyCubeRoot(A,tol);
assert( max(abs(root-root_correct))< tol  , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n' ], ...
      root,root_correct);
%%
disp('test4')
A=0;
tol=1e-6;
root_correct = 0;
root = MyCubeRoot(A,tol);
assert( max(abs(root-root_correct))< tol  , ...
    [ '\nYour output \n root = [' sprintf(' %d ',root) ']\n'   ...
      'Expected output \n root = [' sprintf(' %d ',root_correct) ']\n' ], ...
      root,root_correct);
