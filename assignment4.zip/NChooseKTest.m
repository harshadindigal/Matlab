
%%
disp('test1')
n=4;
k=2;
tol=1e-6;
combinations_correct = [6];
[combinations] = NChooseK(n,k);
assert( combinations==combinations_correct  , ...
    [ '\nYour output \ncombinations = [' sprintf(' %d ',combinations) ']\n'  ...
      'Expected output \ncombinations = [' sprintf(' %d ',combinations_correct) ']\n'   ], ...
      combinations,combinations_correct);
%%
disp('test2')
n=1;
k=1;
tol=1e-6;
combinations_correct = [1];
[combinations] = NChooseK(n,k);
assert( combinations==combinations_correct  , ...
    [ '\nYour output \ncombinations = [' sprintf(' %d ',combinations) ']\n'  ...
      'Expected output \ncombinations = [' sprintf(' %d ',combinations_correct) ']\n'   ], ...
      combinations,combinations_correct);
%%
disp('test3')
n=100;
k=5;
tol=1e-6;
combinations_correct = [7.528752000000001e+07];
[combinations] = NChooseK(n,k);
assert( combinations==combinations_correct  , ...
    [ '\nYour output \ncombinations = [' sprintf(' %d ',combinations) ']\n'  ...
      'Expected output \ncombinations = [' sprintf(' %d ',combinations_correct) ']\n'   ], ...
      combinations,combinations_correct);
%%
disp('test4')
n=4;
k=5;
tol=1e-6;
combinations_correct = [NaN];
[combinations] = NChooseK(n,k);
assert( isnan(combinations) , ...
    [ '\nYour output \ncombinations = [' sprintf(' %d ',combinations) ']\n'  ...
      'Expected output \ncombinations = [' sprintf(' %d ',combinations_correct) ']\n'   ], ...
      combinations,combinations_correct);