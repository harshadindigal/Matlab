function [root]=newtonRoot(f,fDeriv,x0,tol)
%inputs: function, function derivitive, intial x-value, tolerance

%inializations
n = 1; 
root = 1;

%outputs: zero (or root) of function 
%continues to check the next value of x so that it is a certain tolerence
%away form 0
while abs(f(root)) >tol && n <= 10^5
%updates x_n+1
root = x0 - (f(x0)/fDeriv(x0));
%updates x
x0 = root;
%iteration counter
n = n + 1; 
end


end

