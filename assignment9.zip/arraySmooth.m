function [ arrayOut ] = arraySmooth( arrayIn,n,plotsOn )
%Inputs: arrayIn, n, plotsOn

%filter array
filter = ones(2*n + 1);
filter = (1/((2*n + 1).^2)) * filter;
%big array
out = arrayBoundary(arrayIn,n);

[m,z] = size(arrayIn);
%initialization
arrayOut = zeros(m,n);

for i=1:m
    for j=1:z
    number = out(i: 2*n + i,j: 2*n + j) .* filter;
    %output: filter applied to big-array
    arrayOut(i,j) = sum(sum(number));
    end
end
%plot
if strcmp(plotsOn,'on')
surf(arrayOut)
end

end

