function [ n ] = countChar(c, A )
%input: character array A and character c
%number of times c apears in A
x = find(A == c);
%output: number of times c is in A
n = length(x);


end

