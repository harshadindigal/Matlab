  function [outvalue] = arrayBoundary2(arrayIn,n)
    %inputs: arrayIn, 'n'-sized padding
    %creates a symmetric reflection on both sides of arraylist
    outfunction = padarray(arrayIn,[n+1,n+1],'symmetric','both');
    [m,z] = size(outfunction);
    %deletes duplicate rows/columns
    outfunction(n+1,:) = [];
    outfunction(m-1-n,:) = [];
    outfunction(:,n+1) = [];
    outfunction(:,z - 1 -n) = [];
    %output: arrayIn with proper reflection 
    outvalue = outfunction;
    end