function [vk] = findSubstrings(S1,S2)
%inputs: Substring (S2) and String(S2)
%length of substring
S1length = length(S1);
%length of string
S2length = length(S2);
%last index to compare to
lastindex = S2length-S1length + 1;
%initialize 
vk = [];
for(i = 1:lastindex) 
    %everytime substring == a part of string, adds index to matrix
    if strcmp(S2(i:i + (S1length-1))   ,S1)
        %output: indices where substring is in string
        vk = [vk i];
    end
end
end
    

 