function [y] = romanNumeral(x)
ones = { '','I', 'II', 'III', 'IV','V','VI','VII', 'VIII','IX'};
tens = {'','X','XX','XXX','XL','L','LX','LXX','LXXX','XC'};
hundreds = { '', 'C', 'CC', 'CCC', 'CD', 'D', 'DC', 'DCC', 'DCCC','CM'};
thousands = {'', 'M','MM','MMM'};
%input: x
%if x>1000
if x/1000 >= 1
onevalue = (rem(x,10) -rem(x,1))/1;
tenvalue = (rem(x,100) -rem(x,10))/10;
hundredvalue = (rem(x,1000) - rem(x,100))/100;
thousandvalue = (x - rem(x,1000))/1000;
thousandstring = thousands{thousandvalue+1};
hundredstring = hundreds{hundredvalue+1};
tenstring = tens{tenvalue+1};
onestring = ones{onevalue+1};
%output: roman numeral equivalent
y = strcat(thousandstring,hundredstring,tenstring,onestring);
end
%if x > 100
if x/100 >= 1 && x/100 <10
onevalue = (rem(x,10) -rem(x,1))/1;
tenvalue = (rem(x,100) -rem(x,10))/10;
hundredvalue = (rem(x,1000) - rem(x,100))/100;
hundredstring = hundreds{hundredvalue+1};
tenstring = tens{tenvalue+1};
onestring = ones{onevalue+1};
%output: roman numeral equivalent
y = strcat(hundredstring,tenstring,onestring);
end
%if x > 10
if x/10 >= 1 && x/10 < 10
onevalue = (rem(x,10) -rem(x,1))/1;
tenvalue = (rem(x,100) -rem(x,10))/10;
tenstring = tens{tenvalue+1};
onestring = ones{onevalue+1};
%output: roman numeral equivalent
y = strcat(tenstring,onestring);
end
if x >= 1 && x <10
%if x > 0 
onevalue = (rem(x,10) -rem(x,1))/1;
onestring = ones{onevalue+1};
%output: roman numeral equivalent 
y = onestring;
end
end
