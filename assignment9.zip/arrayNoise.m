function [ arrayOut ] = arrayNoise( arrayIn, noise, gain, plotsOn )
%arrayIn dimensions
[row,col] = size(arrayIn);

%if uniform noise
if strcmp(noise,'uniform')
big = rand(row,col) - .5;
big = big * gain;
%noise + array
arrayOut = arrayIn + big;
%if normal noise
else if strcmp(noise, 'normal')
lil = randn(row,col);
lil = lil * gain;
%noise + array
arrayOut = arrayIn + lil;
    end
if strcmp(plotsOn,'on');
disp
surf(arrayOut)
end

end

