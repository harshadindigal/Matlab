function [ arrayOut ] = arraySmooth1( arrayIn,n,plotsOn )
%Inputs: arrayIn, n-sized plot, 
%filter array
filter = ones(2*n + 1);
filter = (1/((2*n + 1).^2)) * filter;
%arrayIn dimensions
[m,z] = size(arrayIn);
%reflected array
out = arrayBoundary2(arrayIn,n);
%Output: applies filter to out array
arrayOut = conv2(out,filter,'valid');

if strcmp(plotsOn,'on');
surf(arrayOut)
end

end
