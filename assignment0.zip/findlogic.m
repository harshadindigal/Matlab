function y = findlogic(x)
% Function to implement given logic
  y =2*x^2 +1;
end