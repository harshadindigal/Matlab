function y = findsin(x)
% Find the sin(x) given tan(x)
y = x/(sqrt((1+x^2)));
end