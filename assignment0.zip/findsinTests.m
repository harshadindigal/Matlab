%%
x = 3/4;
y_correct = 3/5;
assert(isequal(findsin(x),y_correct))
%%
x = 5/12;
y_correct = 5/13;
assert(isequal(findsin(x),y_correct))