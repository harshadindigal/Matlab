%%
x = 13;
y_correct = 339;
assert(isequal(findlogic(x),y_correct))
%%
x = 26;
y_correct = 1353;
assert(isequal(findlogic(x),y_correct))
%%
x = 39;
y_correct = 3043;
assert(isequal(findlogic(x),y_correct))