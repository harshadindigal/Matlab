%Talked to TA Steven, performance test failure happening for no reason
function [estBias, estRmse , ntrialVec ] = p01Masuyama(ntrials, csvfile, r , plotsOn )
%inputs: ntrials , csvfile, r, plotson

%initializations
n = 1;
p = 1;
data = csvread(csvfile,1,0);
basal =data(:,3);
x = data(:,5);
y = data(:,6);
nsample = ceil(ntrials/50);
multiplier = ((750 + (2*r))^2)/(pi*(r^2));

%start trials
while n <= ntrials
%random center
centerx = (750 + 2*r)*rand() - r;
centery = (750 + 2*r)*rand() - r;

%sum of basal's in trees that fall within radius
indexes = (y-centery).^2 + (x - centerx).^2 <= r^2;
basalcorrect = basal(indexes,:);
basalsum = sum(basalcorrect);
estimation = multiplier*basalsum;
tValues(n) = estimation;

%output: estBias, estRmse
if rem(n,nsample) == 0 
    averageT = sum(tValues)/n;
    estBias(p) = 100*((averageT - 311.906)/(311.906));
    estRmse(p) = 100*(sqrt(var(tValues))/311.906);
    p = p + 1;
end
n = n + 1;
end
%output: ntrialVec
ntrialVec= (nsample:nsample:ntrials);

if strcmp(plotsOn,'on')
    figure
    plot(ntrialVec,estBias,'-*');
    grid on
    title(sprintf('Percentage of Bias of TBA estimate using Masuyamas Method \n ntrials = %d, r = %d',ntrials,r))
    xlabel('Number of Trials')
    ylabel('Percentage of Bias of Estimate')
    figure
    plot(ntrialVec,estRmse,'-*');
    grid on
    title(sprintf('Percentage of RMSE of TBA estimate using Masuyamas Method \n ntrials = %d, r = %d',ntrials,r))
    xlabel('Number of Trials')
    ylabel('Percentage of Bias of Estimate')
    
end

