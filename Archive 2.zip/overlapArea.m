function [area]=overlapArea(x,y,r) 
% "overlapArea(xt,yt,rl)" is a function that computes the intersection of
% a disk of radius rl centered at (x,y) with the 750-by-750 region that
% contains the stand of trees.

% Inputs:
%   x = x coordinate of plot center
%   y = y coordinate of plot center
%   r = radius of plot 

% Ouputs: 
%   area = area of overlap between plot and tree stand

% Initialize variables
area=0;
mid=0;
y2=0;
x2=0;

% Use an if-elseif conditional to check for the the following
% conditions for plot overlap in sequence and perform the appropriate calculation

     % plot completely interior to stand 
     if x+r < 750 && y+r < 750 && x-r > 0 && y-r > 0
         area=pi*(r^2);
    
     % plot contains lower left corner
     else if y-r < 0 && x-r < 0 && sqrt((x-0)^2+(y-0)^2) >= r
             x2=sqrt(r^2-(0-y)^2)+x;
             y2=sqrt(r^2-(0-x)^2)+y;
             middlex=(0+x2)/2;
             middley=(0+y2)/2;
             h=r-sqrt((x-middlex)^2+(y-middley)^2);
             hleft=r-abs(0-x);
             arealeft=((r^2)*acos((r-hleft)/r))-((r-hleft)*sqrt(2*r*hleft-(hleft^2)));
             hbottom=r-abs(0-y);
             areabottom=((r^2)*acos((r-hbottom)/r))-((r-hbottom)*sqrt(2*r*hbottom-(hbottom^2)));
             area=(pi*r^2)-arealeft-areabottom;
    
     % plot contains upper left corner
     else if y+r > 750  && x-r < 0 && sqrt((x-0)^2+(y-750)^2) >= r
             x2=sqrt(r^2-(750-y)^2)+x;
             y2=y-sqrt(r^2-(0-x)^2);
             middlex=(0+x2)/2;
             middley=(750+y2)/2;
             h=r-sqrt((middlex-x)^2+(y-middley)^2);
             hright=r-abs(0-x);
             arearight=((r^2)*acos((r-hright)/r))-((r-hright)*sqrt(2*r*hright-(hright^2)));
             htop=r-abs(750-y);
             areatop=((r^2)*acos((r-htop)/r))-((r-htop)*sqrt(2*r*htop-(htop^2)));
             area=(pi*r^2)-arearight-areatop; 
     
     % plot contains upper right corner
     else if y+r > 750 && x+r > 750 && sqrt((x-750)^2+(y-750)^2) >= r
             x2=x-sqrt(r^2-(750-y)^2);
             y2=y-sqrt(r^2-(750-x)^2);
             middlex=(750+x2)/2;
             middley=(750+y2)/2;
             h=r-sqrt((x-middlex)^2+(y-middley)^2);
             hright=r-abs(750-x);
             arearight=((r^2)*acos((r-hright)/r))-((r-hright)*sqrt(2*r*hright-(hright^2)));
             htop=r-abs(750-y);
             areatop=((r^2)*acos((r-htop)/r))-((r-htop)*sqrt(2*r*htop-(htop^2)));
             area=(pi*r^2)-arearight-areatop;
    
     % plot contains lower right corner
     else if y-r < 0 && x+r > 750 && sqrt((x-750)^2+(y-0)^2) >= r
             x2=x-sqrt(r^2-(0-y)^2);
             y2=sqrt(r^2-(750-x)^2)+y;
             middlex=(750+x2)/2;
             middley=(0+y2)/2;
             h=r-sqrt((middlex-x)^2+(y-middley)^2);
             hright=r-abs(750-x);
             arearight=((r^2)*acos((r-hright)/r))-((r-hright)*sqrt(2*r*hright-(hright^2)));
             hbottom=r-abs(0-y);
             areabottom=((r^2)*acos((r-hbottom)/r))-((r-hbottom)*sqrt(2*r*hbottom-(hbottom^2)));
             area=(pi*r^2)-arearight-areabottom;
       
     % Now checking if plot inside corner but overlaps two boundaries
    
     % plot inside lower left corner
     else if y-r < 0 && x-r < 0 && sqrt((x-0)^2+(y-0)^2) < r
             x2=sqrt(r^2-(0-y)^2)+x;
             y2=sqrt(r^2-(0-x)^2)+y;
             middlex=(0+x2)/2;
             middley=(0+y2)/2;
             h=r-sqrt((x-middlex)^2+(y-middley)^2);
             segmentarea=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
             trianglearea=(1/2)*x2*y2;
             area=segmentarea+trianglearea;
    
     % plot inside upper left corner 
     else if y+r > 750  && x-r < 0 && sqrt((x-0)^2+(y-750)^2) < r
             x2=sqrt(r^2-(750-y)^2)+x;
             y2=y-sqrt(r^2-(0-x)^2);
             middlex=(0+x2)/2;
             middley=(750+y2)/2;
             h=r-sqrt((middlex-x)^2+(y-middley)^2);
             segmentarea=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
             trianglearea=(1/2)*(x2)*(750-y2);
             area=segmentarea+trianglearea;
   
     % plot inside upper right corner
     else if y+r > 750 && x+r > 750 && sqrt((x-750)^2+(y-750)^2) < r
             x2=x-sqrt(r^2-(750-y)^2);
             y2=y-sqrt(r^2-(750-x)^2);
             middlex=(750+x2)/2;
             middley=(750+y2)/2;
             h=r-sqrt((x-middlex)^2+(y-middley)^2);
             segmentarea=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
             trianglearea=(1/2)*(750-x2)*(750-y2);
             area=segmentarea+trianglearea;
    
     % plot inside lower right corner
      else if y-r < 0 && x+r > 750 && sqrt((x-750)^2+(y-0)^2) < r
             x2=x-sqrt(r^2-(0-y)^2);
             y2=sqrt(r^2-(750-x)^2)+y;
             middlex=(750+x2)/2;
             middley=(0+y2)/2;
             h=r-sqrt((middlex-x)^2+(y-middley)^2);  
             segmentarea=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
             trianglearea=(1/2)*(750-x2)*y2;
             area=segmentarea+trianglearea; 

     % Now checking if plot inside or outside a boundary
    
     % plot left of left side
     else if x-r < 0 && y-r > 0 && x+r < 750 && y+r < 750 && x <= 0
            h=r-abs(0-x);
            area=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
            
     % plot right of left side  
     else if x-r < 0 && y-r > 0 && x+r < 750 && y+r < 750 && x > 0
             h=r-abs(0-x);
             area=(pi*r^2)-(((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2))));
    
     % plot left of right side 
     else if x+r > 750 && y+r < 750 && x-r > 0 && y-r > 0 && x <= 750
             h=r-abs(750-x);
             area=(pi*r^2)-(((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2))));

     % plot right of right side 
     else if x+r > 750 && y+r < 750 && x-r > 0 && y-r > 0 && x > 750
             h=r-abs(750-x);
             area=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));            

     % plot below bottom side
     else if y-r < 0 && x+r < 750 && y+r < 750 && x-r > 0 && y >= 0  
             h=r-abs(0-y);
             area=(pi*r^2)-(((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2))));
          
     % plot above bottom side  
     else if y-r < 0 && x+r < 750 && y+r < 750 && x-r > 0 && y < 0
             h=r-abs(0-y);
             area=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
 
     % plot below top side
     else if y+r > 750 && x-r > 0 && y-r > 0 && x+r < 750 && y <= 750
             h=r-abs(750-y);
             area=(pi*r^2)-(((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2))));
           
     % plot above top side
     else if y+r > 750 && x-r > 0 && y-r > 0 && x+r < 750 && y > 750
             h=r-abs(750-y);
             area=((r^2)*acos((r-h)/r))-((r-h)*sqrt(2*r*h-(h^2)));
    
     % If no condition above met, plot does not overlap stand
         else area = 0;
             
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
         end
     end
end