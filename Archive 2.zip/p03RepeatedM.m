%function works with correct overlapArea. Talked to TA Steven, performance test failure happening for no reason
function [estBias estRmse ntrialVec] = p03RepeatedM(ntrials,csvfile,r,plotsOn)
%initializations
data = csvread(csvfile,1,0);
basal =data(:,3);
x = data(:,5);
y = data(:,6);
multiplier = ((750)^2)/(pi*(r^2));
totalarea = pi*r^2;
rchange = r;
nsample = ceil(ntrials/50);
tValues = [];
estRmse = [];
estBias = [];
numberofplots = [];

%all overlap areas (use correct .p file to test)
for z=1:length(x)
     a(z)=overlapArea(x(z),y(z),r);      
end

%trials
for i =1:ntrials
%inter-trial initializations
totalbasalsum = 0;
runningtotalarea = 0;
p = -1;

%repeated Masuyama
while runningtotalarea < totalarea
centerx = (750 + 2*rchange)*rand() - rchange;
centery = (750 + 2*rchange)*rand() - rchange;
indexes = (y-centery).^2 + (x - centerx).^2 <= rchange^2;
basalcorrect = basal(indexes,:);
totalbasalsum = totalbasalsum + sum(basalcorrect);
d = overlapArea(centerx,centery,rchange);
runningtotalarea = runningtotalarea + d;
rchange = sqrt((totalarea - runningtotalarea)/pi);
p = p + 1;
end

%t-value
estimation = multiplier*totalbasalsum;
tValues = [tValues estimation];
numberofplots = [numberofplots p];

%output: estBias , estRmse
if rem(i,nsample) == 0 
    averageT = sum(tValues)/i;
    estBias = [estBias 100*((averageT - 311.906)/(311.906))];
    estRmse= [estRmse 100*(sqrt(var(tValues))/311.906)];
end
end
%output: ntrialVec
ntrialVec= (nsample:nsample:ntrials);

%plot

if strcmp(plotsOn,'on')==1
    figure
    plot(ntrialVec,estBias,'-*');
    grid on
    title(sprintf('Percentage of Bias of TBA estimate using Masuyamas Method \n ntrials = %d, r = %d',ntrials,r))
    xlabel('Number of Trials')
    ylabel('Percentage of Bias of Estimate')
    figure
    plot(ntrialVec,estRmse,'-*');
    grid on
    title(sprintf('Percentage of RMSE of TBA estimate using Masuyamas Method \n ntrials = %d, r = %d',ntrials,r))
    xlabel('Number of Trials')
    ylabel('Percentage of Bias of Estimate')
    
    figure
    histogram(numberofplots);
    

end
