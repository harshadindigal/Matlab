%Talked to TA Steven, performance test failure happening for no reason
function[estBias estRmse ntrialVec] = p02MeasurePi(ntrials,csvfile,r,plotsOn)
% INPUT(S) - ntrials, csvfile, r, plotsOn  


% Initializations
t=311.906;
nsample=ceil(ntrials/50);
Area=750^2;
estBias=[]; 
estRmse=[];
tValues=[];

%data
data=csvread(csvfile,1,0);
x=data(:,5);
y=data(:,6);
basil=data(:,3);

%overlap areas for each point
for z=1:length(basil)
     a(z)=overlapArea(x(z),y(z),r);      
end

for i=1:ntrials
% calculate random center point in stand
randcentx=rand(1)*750;
randcenty=rand(1)*750;


% calculate t-value
indexes=(((x-randcentx).^2)+((y-randcenty).^2))<r^2;
value=basil(indexes)./a(indexes)';
basalsum=sum(value);
estimation=basalsum * Area;
tValues=[tValues estimation];

% OUTPUT: estBias, estRmse
if mod(i,nsample)==0
estBias=[estBias (100*((mean(tValues)-t)/t))];
estRmse=[estRmse (100*(sqrt(var(tValues))/t))];
end
end

% OUTPUT: ntrialVec
ntrialVec= (nsample:nsample:ntrials); 

% plot
if strcmp(plotsOn,'on')==1
    figure(1);
    plot(ntrialVec,estBias,'-*b');
    grid on;
    title({'Percentage Bias of TBA Estimate Using Measure Pi Method','ntrials=1e+05, r=37, Normalized Average Plot Area=0.963'});
    xlabel('Number of Trials');
    ylabel('Percentage Bias of Estimate');
    saveas(gcf,sprintf('p02MeasurePi_estBias.pdf'),'pdf');
    
    figure(2);
    plot(ntrialVec,estRmse,'-*b');
    grid on;
    title({'Percentage RMSE of TBA Estimate Using Measure Pi Method','ntrials=1e+05, r=37, Normalized Average Plot Area=0.963'});
    xlabel('Number of Trials');
    ylabel('Percentage RMSE of Estimate');
    saveas(gcf,sprintf('p02MeasurePi_estRmse.pdf'),'pdf');
    
end

end