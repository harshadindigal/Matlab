function []  = rmseVerR( ntrials , tbamethod) 
%inputs: ntrials, tbamethod

%initializations
r = 5;
rvals = [];
rmsevals = [];
rmsecount = 1;
%plot-points
while r <= 50 
    [a,b,c] = tbamethod(ntrials,'trees.csv',r,'off');
    rmsevals(rmsecount) = b(length(b));
    rvals(rmsecount) = r;
    r = r + 5;
    rmsecount = rmsecount + 1;
end

%plot
figure
plot(rvals,rmsevals,'-*');
grid on
title(sprintf('Percentage of Bias of TBA estimate using p03RepeatedM Method versus Plot Radius \n ntrials = %d',ntrials))
xlabel('Plot Radius')
ylabel('Percentage of RMSE of Estimate')
end
