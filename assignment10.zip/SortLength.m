function [B] = SortLength(C)
%input: C

%initialization
lengthsizes = zeros(1,length(C));

%loops through C and deletes duplicates and creates a length array
for i =1: length(C)
    C{i} = deleteDups(C{i});
    lengthsizes(i) =  length(C{i});
end
%orders length descending
[newstrings, index] = sort(lengthsizes,'descend');

%output: B
B = C(index);
end