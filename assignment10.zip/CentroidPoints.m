function [Q3] = CentroidPoints(P)
%input: P

%inialization
plength = length(P);
runningsumx = 0;
runningsumy = 0;
x = [];
y = [];
%loop through to find x and y values
for i = 1:plength
   runningsumx = runningsumx + P(i).x; 
   runningsumy = runningsumy + P(i).y;
   x = [x P(i).x];
   y = [y P(i).y];
end

%OUTPUT: center of x and y
Q3x = runningsumx / plength;
Q3y = runningsumy / plength; 
Q3 = struct('x',Q3x,'y',Q3y);

%plot
plot(x,y,'*');
hold on
plot(Q3x, Q3y,'O');
title(sprintf('Test of CentroidPoints \n Centroid = (%d,%d)', Q3x , Q3y))
xlabel('x')
ylabel('y')
end