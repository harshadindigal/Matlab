function [string_out] = deleteDups(string_in)
%input: string_in

%initialization
emptystring = '';
%loops through each character to see if duplicate
for i = 1:length(string_in)
    if any(emptystring == string_in(i)) == 0
        emptystring = strcat(emptystring,string_in(i));
    end
    
%output: string_out
string_out = emptystring;
end
