function [data_out] = frozenSensor(sensor_data,threshold)
%input:sensor_data, threshold

%seperate out temperature, wind, and humidity values
temperature = sensor_data(:,1);
windvelocity = sensor_data(:,2);
humidity = sensor_data(:,3);
%indexes where sensor_data falls under/over threshold
index = find(temperature <= threshold(1) & windvelocity <= threshold(2) & humidity >= threshold(3));

%discarded
discarded = sensor_data(index, :);
%cleaned-up
sensor_data(index, :) = [];

%output:
data_out = {sensor_data; discarded};

end