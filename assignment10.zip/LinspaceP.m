function [P] = LinspaceP(Q1, Q2, n)
%inputs: Q1 , Q2, n

%all x points
linspacepointsx = linspace(Q1(1).x,Q2(1).x,n);
%all y points
linspacepointsy = linspace(Q1(1).y,Q2(1).y,n);

plot(linspacepointsx,linspacepointsy,'*')
title('Test of linspaceP')
xlabel('x')
ylabel('y')
%put corresponding x and y points into structure
for i = 1:length(linspacepointsx)
   %output: points in structure
    P(i) = struct('x',linspacepointsx(i),'y',linspacepointsy(i));
end

end