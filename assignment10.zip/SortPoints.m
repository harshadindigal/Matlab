function [Q1,Q2,Q3] = SortPoints(P)
%inputs: P 

%initialization
distancearray = [];
distancefromcenter = [];
%distance from origin
for i = 1:length(P)
distancearray = [distancearray ,sqrt((P(i).x)^2 + (P(i).y)^2)];
end
%indexes of sorted in ascending order 
[sorteddistance,indexes] = sort(distancearray);

%points sorted in distance order
newStructure = P(indexes);
%output: median, centroid 
Q1 = newStructure(round(length(newStructure)/2));
Q3 = CentroidPoints(P);
for i = 1:length(P)
distancefromcenter = [distancefromcenter, sqrt((P(i).x - Q3.x)^2 + ((P(i).y - Q3.y)^2))];
end
[sorteddistancefrcenter, places] = sort(distancefromcenter);
%output: closest point to centroid
Q2 = P(places(1));
%plot
plot(Q3.x,Q3.y,'o')
plot(Q1.x,Q1.y,'diamond')
plot(Q2.x,Q2.y,'square')
title(sprintf('Test of SortPoints \n Centroid = (%d,%d)', Q3.x , Q3.y))
end