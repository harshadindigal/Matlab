function [ A,approx ] = spheroid_area( r1,r2 )
% inputs: major axis radius and minor axis radius (r1, r2)
theta = acos(r2/r1); %theta value used in area formula
%outputs:
A= (2*pi)*(r1^2+((r2^2)/sin(theta)*(log10(cos(theta)/(1-sin(theta))))));%area 
approx= 4*pi*(((r1 + r2)/2)^2);%surface area 
end

