function [ P1, P2, P3, P4 ] = ellipse_perim(a,b)

%  Approximations
h =(((a-b)/(a+b))^2); %h-value used in perimeter estimation formula

P1=pi*(sqrt((2*(a^2 + b^2))-(((a-b)^2)/2)));%first perimeter estimation formula
P2=pi*(a+b)*((1 + (h/8))^2);%second perimeter estimation formula
P3= pi*(a+b)*((256-(48*h)-(21*(h^2)))/(256-(112*h)+(3*(h^2))));%third perimeter estimation formula
P4=pi*(a+b)*((3-(sqrt(1-h)))/2);%fourth perimeter estimation formula
end

