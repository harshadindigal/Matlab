%%
r1=2;
r2=1;
A_correct = 29.2823;
approx_correct=28.2743;
eps = 1e-4;
[A,approx]=spheroid_area(r1,r2);
assert(abs(A-A_correct)< eps && abs(approx-approx_correct)< eps)
%%
r1=4;
r2=1;
A_correct = 106.3462;
approx_correct=78.5398;
eps = 1e-4;
[A,approx]=spheroid_area(r1,r2);
assert(abs(A-A_correct)< eps && abs(approx-approx_correct)< eps)
%%
r1=6378.137;
r2=6356.752;
A_correct = 3.661152407302249e+08;
approx_correct=5.094953216397448e+08;
eps = 1e-4;
[A,approx]=spheroid_area(r1,r2);
assert(abs(A-A_correct)< eps && abs(approx-approx_correct)< eps)
