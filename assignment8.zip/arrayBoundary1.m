function [ arrayOut ] = arrayBoundary1(arrayIn, n)
%inputs: arrayIn, n-padding
%outputs: 

%mirror image on both sides of rows(begining and end)
arrayOut = padarray(arrayIn,[n,n],'symmetric','both');
end
