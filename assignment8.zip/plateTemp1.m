function [ TVals ] = plateTemp1( n,hs,plotsOn )
%inputs: n, hs, plotOn

%anonymous call of T_plate2
T_plate2 = @(x,y) T_plate1(x,y,hs)  ;
%output:
TVals = fOnGrid(linspace(0,6,n),linspace(0,4,n),T_plate2);

%plot:
numb = strcmp(plotsOn,'on');
if( numb == 1) 
    contourf(linspace(0,6,n),linspace(0,4,n),TVals)
    xlabel('x');
    ylabel('y');
    title(sprintf('Cross-Section of temperature grid for heat source locations (%d,%d) to (%d,%d)',hs(1,1),hs(1,2),hs(2,1),hs(2,2)));
end
end