function [ TVals] = plateTemp2( n,hs,plotsOn)
%inputs: n, hs, plotsOn

%x-y grid outputed as an arraylist
[X,Y] = meshgrid(linspace(0,6,n),linspace(0,4,n));

%output:
TVals =  T_plate1(X,Y,hs);

%plot
numb = strcmp(plotsOn,'on');
if( numb == 1) 
    contourf(linspace(0,6,n),linspace(0,4,n),TVals)
    xlabel('x');
    ylabel('y');
    title(sprintf('Cross-Section of temperature grid for heat source locations (%d,%d) to (%d,%d)',hs(1,1),hs(1,2),hs(2,1),hs(2,2)));
end
end

