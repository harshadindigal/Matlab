function [ TVals ] = crossSection( n, hs, endpts, plotsOn)
%inputs: n, hs, endpts, plotsOn

%x-array
x = linspace(endpts(1,1),endpts(2,1),n);
%y-array
y = linspace(endpts(1,2),endpts(2,2),n);

%output:
TVals = T_plate1(x,y,hs);
%min
minimum = min(min(TVals));
%max
maximum = max(max(TVals));
%plots:
numb = strcmp(plotsOn,'on');
if( numb == 1) 
    plot(linspace(0,1,n),TVals);
    xlabel(sprintf('Fraction of distance from (%d,%d) to (%d,%d)',endpts(1,1),endpts(1,2),endpts(2,1),endpts(2,2)));
    ylabel('Temperature');
    title(sprintf('Cross-Section of temperature grid for heat source locations (%d,%d) to (%d,%d)',hs(1,1),hs(1,2),hs(2,1),hs(2,2)));
end
end

