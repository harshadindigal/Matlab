function [ arrayOut ] = arrayBoundary(arrayIn, n)
%dimensions of arrayIn
[m,z] = size(arrayIn);
%matrix of zeros for arrayIn + n-padding
arrayinter = zeros(m + 2*n,z + 2*n);
%arrayIn placed in center of zero matrix
arrayinter(n+1:m + n, n+1:z+n) = arrayIn;  

%initialization
h = 1;
%mirrors from edges
while h <= n
%left
arrayinter(:,n+1-h) = arrayinter(:,n + 1 + h);
%top
arrayinter(n+1-h,:) = arrayinter(n + 1 + h,:);
%right
arrayinter(:,z + n + h) = arrayinter(:, z + n - h);
%bottom
arrayinter(n + m + h,:) = arrayinter(n + m - h,:);
h = h + 1;
end
%output:
arrayOut = arrayinter;
end

