function [root] = findRoot2( x0, tol )
%inputs: x0 and tolerance

func = @(x)3*x.^4 -5*x.^3 - 12*x.^2;
funcderiv=@(x)((12)*(x.^3)) - ((15)*(x.^2)) - (24*x);
%calls localfunction newtonRoot to calculate root
    function [root] = newtonRoot2(func, funcderiv, x0, tol)
        %inializations
         n = 1; 
        root = 1;

        %outputs: zero (or root) of function 
        %continues to check the next value of x so that it is a certain tolerence
        %away form 0
        while abs(func(root)) >tol && n <= 10^5
        %updates x_n+1
        root = x0 - (func(x0)/funcderiv(x0));
        %updates x
        x0 = root;
        %iteration counter
        n = n + 1; 
        end
    
    end
root = newtonRoot2(func, funcderiv,x0, tol);
%plot of x-values (50) from -2 to 3.25
xplot = linspace(-2,3.25);
%corresponing vector of f(x) values
y = func(xplot);

figure
%plots x and f(x) values 
plot(xplot,y);
hold on
grid on

%highlights the zero of the function
plot(root, func(root),'ro')
%highlights the initial x of the function
plot(x0, func(x0),'bo')

%graph labels
legend('f(x)','f(x) = 0', 'f(x0)')
xlabel('x')
ylabel('f(x)')
title(sprintf('Roots of f(x) = 3*x^4 -5*x^3 - 12*x^2 Using Newtons Method for tol = %d',tol))


end

