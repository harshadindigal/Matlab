function [ P ] = ellipsePerim( a,b,tol,plotsOn)
%inputs: a,b,tol,plotsOn

%intitializations
n = 2;
%output:
while (abs(P_inner0(a,b,n+1) - P_inner0(a,b,n))/P_inner0(a,b,n+1)) >= tol && n < 10^4 %loopguard
n = n + 1;
%update p-value while relative error < tolerance
P = P_inner0(a,b,n+1);
end


