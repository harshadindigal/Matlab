function [P ] = ellipsePerim1(a,b,tol,plotsOn)
%inputs: a,b,tol,plotsOn  

%subfunction
    function [P, x, y] = P_inner1(n)
% a and b are the semiaxes of an ellipse E.
% n is a positive integer bigger than 2.
% P is the perimeter of the inner polygon whose
% vertices are on E.

% Initialize a running sum variable to zero,
% Other initializations
theta = (2*pi)/n;
innerSum = 0;

% Compute xy-coordinates of vertex k
    k=0;
    xk = a*cos(k*theta);
    yk = b*sin(k*theta);
for k=1:n
    % Compute xy-coordinates of vertex k
    xk1 = a*cos(k*theta);
    yk1 = b*sin(k*theta);
    x(k) = xk1;
    y(k) = yk1;
    % Add in the distance between them to 
    % the running sum 
    dk = sqrt((xk-xk1)^2 + (yk-yk1)^2);
    innerSum = innerSum + dk;
    
    % Save new point as old point for next iteration
    xk=xk1;
    yk=yk1;
end


P = innerSum;  % Compute total perimeter of polygon across
                 % all four quadrants
    end
%initialization
n = 2;
%output: 
while (abs(P_inner1(n+1) - P_inner1(n))/P_inner1(n+1)) >= tol 
n = n + 1;
%update p-value while relative error < tolerance
P = P_inner1(n+1);
end


end

