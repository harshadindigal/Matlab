function [P ] = ellipsePerim2( a,b,tol,plotOn )
%inputs: a,b,tol,plotsOn

%initializations
n = 2;
while (abs(P_inner2(a,b,n+1) - P_inner2(a,b,n))/P_inner2(a,b,n+1)) >= tol 
n = n + 1;
%update p-value while relative error < tolerance
P = P_inner2(a,b,n+1);
end


end

