function [P, x, y] = P_inner4(a,b,n)
% a and b are the semiaxes of an ellipse E.
% n is a positive integer bigger than 2.
% P is the perimeter of the inner polygon whose
% vertices are on E.

% Initialize a running sum variable to zero,
% Other initializations
theta = (pi/2)/n;

% Compute xy-coordinates of vertex k
   
    k=0:n;
    % Compute xy-coordinates of vertex k
    xk1 = a*cos(k*theta);
    yk1 = b*sin(k*theta);
  
    % Add in the distance between them to 
    % the running sum 
    xk0 = xk1(1:end-1);
    yk0 = yk1(1:end-1);
    yk = yk1(2:end);
    xk = xk1(2:end);
    dk = sqrt((xk-xk0).^2 + (yk-yk0).^2);
    P =  4*sum(dk);
    
    % Save new point as old point for next iteration
    x=xk1;
    y=yk1;
end
