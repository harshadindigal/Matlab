function [ T_out ] = tConverterIf(T,u1,u2)
% inputs: T, u1, u2
%outputs:
if u1 == 'C' %checks to see if the temperature to convert is Celcius
    if u2 == 'F' %checks to see if temperature to convert to is Fahrenheit
    T_out = ((9/5)*T) + 32; 
    elseif u2 == 'K' %checks to see if temperature to convert to is Kelvin
    T_out = T + 273.15; 
    elseif u2 == 'C' %checks to see if temperature to convert to is Celcius
    T_out = T; 
    elseif u2 == 'R' %checks to see if temperature to convert to is Rankine
    T_out = ((T + 273.15)*((9/5))); 
    end
end

if u1 == 'F' %checks to see if the temperature to convert is Fahrenheit
    if u2 == 'C' %checks to see if temperature to convert to is Celcius
    T_out = ((T-32)*(5/9)); 
    elseif u2 == 'K' %checks to see if temperature to convert to is Kelvin
    T_out = ((T + 459.67)*(5/9)); 
    elseif u2 == 'R' %checks to see if temperature to convert to is Rankine
    T_out = T + 459.67; 
    elseif u2 == 'F' %checks to see if temperature to convert to is Fahrenheit
    T_out = T; 
    end
end

if u1 == 'K' %checks to see if the temperature to convert is Kelvin
    if u2 == 'F' %checks to see if temperature to convert to is Fahrenheit
    T_out = ((9/5)*T) - 459.67;
    elseif u2 == 'R' %checks to see if temperature to convert to is Rankine
    T_out = T * (9/5); 
    elseif u2 == 'C' %checks to see if temperature to convert to is Celcius
    T_out = T - 273.15; 
    elseif u2 == 'K' %checks to see if temperature to convert to is Kelvin
    T_out = T; 
    end
end
if u1 == 'R' %checks to see if the temperature to convert is Rankine
    if u2 == 'F' %checks to see if temperature to convert to is Fahrenheit
    T_out = T - 459.67; 
    elseif u2 == 'C' %checks to see if temperature to convert to is Celcius
    T_out = ((T-491.67)*(5/9)); 
    elseif u2 == 'K' %checks to see if temperature to convert to is Kelvin
    T_out = T * (5/9); 
    elseif u2 == 'R' %checks to see if temperature to convert to is Rankine
    T_out = T; 
    end
end
    
end

