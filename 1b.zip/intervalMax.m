function [maxVal]=intervalMax(L,R)
%inputs: L (minimum x on range) and R (maximum x on range) 
a = L/(2*pi);     % determines how many interations of 2pi are in L and R
b = R/(2*pi);

if floor(b) - floor(a) > 0  %The floor function rounds the iteration number
   maxVal = 1;              %to the closest lowest integer. If the difference 
                            %between the higher x and lower x is >1, then
                            %2pi is int he interval and the function HAS to hit
                            %it's max of 1

%if a multiple of 2pi isn't on the interval, the max has to be one of the
%endpoints
else
if cos(L) > cos(R)
    maxVal = cos(L);
else
    maxVal = cos(R);
end


end
