function [ xt,yt ] = makeEllipseRand(theta, n ,n_noise)
%inputs: tilt angle: theta, number of points: n, index at which random
%perturbation: n_noise 

%outputs: x(t) (an array of points in the x-axis depending on theta)
%         y(t) (an array of points in the y-axis depending on theta)
%         graph plot of y(t) vs x(t)

%intial t degree
t = 0;

%how much t should incriment to have n-number of points
counter = (2 * pi)/ (n-1);

% keeps track of the size of resultant vector/assigns indexs
index = 1;

%converts theta to radians
thetaradians = (theta * pi)/180;

%one complete cycle of t

while t <= (2*pi)

%if the the index is an iteration of n_noise or is at 1, random "noise" is
%added
if index == 1 || rem(index,n_noise) == 0
x = rand - .5;
y = rand -.5;
xt(index) = (4*(cos(t))*(cos(thetaradians))) - (2*(sin(t))*(sin(thetaradians))) + x;
yt(index)= (2*(sin(t))*(cos(thetaradians))) + (4*(cos(t))*(sin(thetaradians))) + y;
t = t + counter;
index = index + 1;

%every other index, the x and y values are normal
else
xt(index) = (4*(cos(t))*(cos(thetaradians))) - (2*(sin(t))*(sin(thetaradians)));
yt(index)= (2*(sin(t))*(cos(thetaradians))) + (4*(cos(t))*(sin(thetaradians)));
t = t + counter;
index = index + 1;
end
end

%graph
figure
fig = plot(xt,yt,'*');
xlabel('x(t)');
ylabel('y(t)');
title(sprintf('Noisy %d-point Ellipse with Tilt Angle %d',n,theta));
end

