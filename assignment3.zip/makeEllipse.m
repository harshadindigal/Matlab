function [ xt,yt ] = makeEllipse(theta, n )
%inputs: tilt angle: theta and number of points: n
%outputs: x(t) (an array of points in the x-axis depending on theta)
%         y(t) (an array of points in the y-axis depending on theta)
%         graph plot of y(t) vs x(t)

%intial t degree
t = 0;

%how much t should incriment to have n-number of points
counter = (2 * pi)/ (n-1); 

% keeps track of the size of resultant vector/assigns indexs
index = 1;

%converts theta to radians
thetaradians = (theta * pi)/180;

%one complete cycle of t
while t <= (2*pi)
%x-points
xt(index) = (4*(cos(t))*(cos(thetaradians))) - (2*(sin(t))*(sin(thetaradians)));

%y-points
yt(index)= (2*(sin(t))*(cos(thetaradians))) + (4*(cos(t))*(sin(thetaradians)));

%incriment
t = t + counter;
index = index + 1;
end
%graph
plot(xt,yt);
figure
fig = plot(xt,yt,'*');
xlabel('x(t)');
ylabel('y(t)');
title(sprintf('Noisy %d-point Ellipse with Tilt Angle %d',n,theta));
end


