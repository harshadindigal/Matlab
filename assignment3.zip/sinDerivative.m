function [h_best,e_best]=sinDerivative(x)
%inputs: x (input variable)

%initializations:
count = 1;
h_best = 1000;
e_best = 1000;
b = 1;

%array of h-values
while b <= 16
 h(b) = 1/(10^(b));
 b = b + 1;
end
    
%outputs: e_best: lowest error
%         h_best: h that makes the error the lowest
while count <= 16
%array of all e-values
e(count) = abs(((sin(x + h(count)) - sin (x))/h(count))- cos(x));

%if current e-value is less than best e-value, best e-value is current
if(e_best > e(count))
h_best=h(count);
e_best=e(count);
end
%incriment
count = count + 1;
end
%graph
figure
loglog(h,e,'*');
set(gca,'XDir','reverse');
xlabel('h')
ylabel('Error');
title(sprintf('Error in Derivative of Sin Approximation at x = %0.3d radians',x));

end







