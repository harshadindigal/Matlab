function [ f ] = makeVec( n )
%inputs: n 

%outputs: generates a length-10 vector according to a formula that intakes
%n

count = 1; %keeps track of the size of resultant vector/assigns indexs 

%case where index = 1
while count == 1
    f(count)= n;
    count = count +1;
end

%rest of the cases until size 10
while count > 1 && count <=10 
    
    %if(f(k-1) is even
    if rem(f(count-1),2) == 0 
      b = f(count-1)/2;
      f(count) = b;
      count = count + 1;
      
     %if(f(k-1) is odd
    else
        a = (3*(f(count-1))) + 1;
        f(count) = a;
        count = count + 1;
    end
end
        

end

