function [h_best,e_best]=sinDerivativeVec(x)
%inputs: x (input variable)

%initializations:
count = 1;
h_best = 1000;
e_best = 1000;

%outputs: e_best: lowest error
%         h_best: h that makes the error the lowest
while count <= 16
%current h-value
h = 1/(10^(count));
%array of all e-values
e(count)= abs(((sin(x + h) - sin (x))/h)- cos(x));

%h-value that returns the smallest error
if(e(count) == min(e))
    h_best = h;
end
%incriment
count = count + 1;
end
%finds lowest error in the arraylist of Errors
e_best = min(e);
end







